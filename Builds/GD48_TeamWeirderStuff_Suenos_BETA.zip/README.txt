Controls:

Move: Left & Right Arrows
Jump: Space
Switch Worlds: Shift (Hold to switch when falling)
Use Vent: X
Pause: Escape
E: Kill Player
